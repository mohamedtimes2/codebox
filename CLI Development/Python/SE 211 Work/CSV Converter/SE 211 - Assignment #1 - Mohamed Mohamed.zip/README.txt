Please run the csvmenu.py file using a Python 3.7 interpreter, preferrable using a IDE.
All files and libraries must be in the same folder.
A dummy CSV file is provided as an example of a file supported by the set of programs.